import { useState } from 'react';

const ROWS = 6;
const COLS = 7;

export default function Connect4() {
  const [board, setBoard] = useState(Array(ROWS).fill(null).map(() => Array(COLS).fill(null)));
  const [player, setPlayer] = useState('🔴');
  const [winner, setWinner] = useState(null);

  const dropDisc = (col) => {
    if (winner) return;

    const newBoard = [...board.map(row => [...row])];
    for (let row = ROWS - 1; row >= 0; row--) {
      if (!newBoard[row][col]) {
        newBoard[row][col] = player;
        if (checkWin(newBoard, row, col, player)) {
          setWinner(player);
        }
        setBoard(newBoard);
        setPlayer(player === '🔴' ? '🟡' : '🔴');
        break;
      }
    }
  };

  const checkWin = (board, row, col, player) => {
    const directions = [
      [[0, 1], [0, -1]],
      [[1, 0], [-1, 0]],
      [[1, 1], [-1, -1]],
      [[1, -1], [-1, 1]]
    ];
    for (const [[dx1, dy1], [dx2, dy2]] of directions) {
      let count = 1;
      count += countDirection(board, row, col, dx1, dy1, player);
      count += countDirection(board, row, col, dx2, dy2, player);
      if (count >= 4) return true;
    }
    return false;
  };

  const countDirection = (board, row, col, dx, dy, player) => {
    let count = 0;
    for (let i = 1; i < 4; i++) {
      const r = row + dx * i;
      const c = col + dy * i;
      if (r < 0 || r >= ROWS || c < 0 || c >= COLS || board[r][c] !== player) break;
      count++;
    }
    return count;
  };

  const resetGame = () => {
    setBoard(Array(ROWS).fill(null).map(() => Array(COLS).fill(null)));
    setPlayer('🔴');
    setWinner(null);
  };

  return (
    <div className="flex flex-col items-center p-4">
      <h1 className="text-2xl font-bold mb-2">Connect 4</h1>
      {winner ? (
        <div className="mb-2 text-xl">🎉 {winner} wins!</div>
      ) : (
        <div className="mb-2 text-xl">Current Player: {player}</div>
      )}
      <div className="grid grid-cols-7 gap-1">
        {board.map((row, rowIndex) =>
          row.map((cell, colIndex) => (
            <div
              key={`${rowIndex}-${colIndex}`}
              className="w-12 h-12 bg-blue-400 flex items-center justify-center text-2xl rounded-full cursor-pointer"
              onClick={() => dropDisc(colIndex)}
            >
              {cell || ''}
            </div>
          ))
        )}
      </div>
      <button onClick={resetGame} className="mt-4 px-4 py-2 bg-green-500 text-white rounded-xl shadow">
        Reset
      </button>
    </div>
  );
}
