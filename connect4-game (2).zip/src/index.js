import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import Connect4 from './App';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <Connect4 />
  </React.StrictMode>
);
